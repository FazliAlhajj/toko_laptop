<?php 

session_start();
require 'functions.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu')
        window.location = '../login/index.php';
    </script>
    ";
}

    $transaksi = query("SELECT * FROM transaksi");

?> 

<?php 
    require '../layout/sidebar.php' ; ?>

<div class="main">
    <h3>Data Transaksi</h3>
    
    <a href="tambah_transaksi.php" class="tambah">Tambah Transaksi</a>
    <table>
        <tr>
            <th>No.</th>
            <th>Jumlah Produk</th>
            <th>Tanggal Transaksi</th>
            <th>Id Produk</th>
            <!-- <th>Id User</th> -->
            <th>Aksi</th>
        </tr>   

        <?php $i = 1; ?>
        <?php foreach($transaksi as $data) : ?>
        <tr>
            <td><?= $i; ?></td>
            <td><?= $data["jumlah_produk"]; ?> </td>
            <td><?= $data["tgl_transaksi"]; ?></td>
            <!-- <td><?= $data["id_produk"]; ?></td> -->
            <td><?= $data["id_user"]; ?></td>
            <td>
                <a href="edit_transaksi.php?id=<?= $data["id_produk"]; ?>" class="edit">Edit</a>
                <a href="hapus_transaksi.php?id=<?= $data["id_produk"]; ?>" class="hapus" onClick="return confirm('Anda yakin ingin menghapus?');">Hapus</a>
            </td>
        </tr>
        <?php $i++; ?>
        <?php endforeach; ?>
    </table>
