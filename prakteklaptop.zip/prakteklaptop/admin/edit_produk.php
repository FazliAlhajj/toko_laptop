<?php
session_start();
require 'functions.php';

$id = $_GET["id"];
$produk = query("SELECT * FROM produk WHERE id_produk = '$id'")[0];



if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('silahkan login terlebih dahulu')
            window.location: '../login/index.php';
        </script>
    ";
}

if(isset($_POST["submit"])){
    if(editProduk($_POST) > 0){
        echo "
        <script type='text/javascript'>
            alert('Data user berhasil diedit');
            window.location = 'produk.php';
        </script>
    ";
    }else{
        echo "
        <script type='text/javascript'>
            alert('Data user gagal diedit');
            window.location = 'produk.php';
        </script>
    ";
    }
}


?>

<?php require '../layout/sidebar.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
    
    <div class="main">
        <div class="box">
            <h3>Edit produk</h3>
    
            <form action="updateproduk.php" method="POST" enctype="multipart/form-data
            ">
                <input type="hidden" name="id_produk" value="<?= $produk["id_produk"]; ?>"> 

                <label for="nama_produk">Nama Produk</label>
                <input type="text" name="nama_produk" class="form-control" value="<?= $produk["nama_produk"] ?>">
    
                <label for="merk_produk">merk_produk</label>
                <input type="text" name="merk_produk" class="form-control" value="<?= $produk["merk_produk"]; ?>">
    
                <label for="harga">harga</label>
                <input type="text" name="harga" class="form-control" value="<?= $produk["harga"]; ?>">

                <button type="submit" name="kirim">Edit</button>
            </form>
        </div>
    </div>
</body>
</html>