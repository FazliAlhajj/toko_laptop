<?php 
session_start();
require 'functions.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu')
        window.location = '../login/index.php';
    </script>
    ";
}

if(isset($_POST["kirim"])){
    if(tambahTransaksi($_POST) > 0){
        echo "
        <script type='text/javascript'>
            alert('Data transaski Berhasil Ditambahkan')
            window.location = 'transaski.php';
        </script>
        ";
    }else{
        echo "
        <script type='text/javascript'>
            alert('Data transaski Gagal Ditambahkan')
            window.location = 'transaski.php';
    </script>
        ";
    }
}

?>

<?php require '../layout/sidebar.php'?>

<div class="main">
    <div class="box">
        <h3>Tambah Data transaski</h3>

        <form action="" method="post" enctype="multipart/form-data">

        <label for="jumlah_produk">Jumlah Produk</label>
            <input type="text" name="jumlah_produk" id="jumlah_produk" class="form-control">

            <label for="tgl_transaksi">Tanggal Transaksi</label>
            <input type="date" name="tgl_transaksi" id="tgl_transaksi" class="form-control">

            <!-- <label for="id_produk">ID Produk</label>
            <input type="text" name="id_produk" id="id_produk" class="form-control"> -->

            <label for="id_user">ID User</label>
            <input type="text" name="id_user" id="id_user" class="form-control">
            
            </select>
            <button tytpe="submit" name="kirim">Tambah</button>
        </form>
    </div>
</div>