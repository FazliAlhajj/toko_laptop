<?php 
session_start();
require 'functions.php';

$id = $_GET["id"];
$transaksi = query("SELECT * FROM transaksi WHERE id_produk = '$id'")[0];

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu')
        window.location = '../login/index.php';
    </script>
    ";
} 

if(isset($_POST["submit"])){
    if(editTransaksi($_POST) > 0){
    echo "
        <script type='text/javascript'>
            alert('Data transaksi berhasil diubah');
            window.location = 'transaksi.php';
        </script>
    ";
    }else{
        echo "
        <script type='text/javascript'>
            alert('Data transaksi gagal diubah');
            window.location = 'transaksi.php';
        </script>
    ";
    }
    }   

require '../layout/sidebar.php'; 
?>

    <div class="main">
        <div class="box">
            
        <h3>Edit Data transaksi</h3>

        <form action="" method="POST">
            <input type="hidden" name="id_produk" value="<?= $transaksi["id_produk"]; ?>">

            <label for="jumlah_produk">Jumlah Produk</label> 
            <input type="text" name="jumlah_produk" id="jumlah_produk" 
            class="form-control" value="<?= $transaksi["jumlah_produk"]; ?>"> 

            <label for="tgl_transaksi">Tanggal transaksi</label> 
            <input type="date" name="tgl_transaksi" id="tgl_transaksi" class="form-control" value="<?= $transaksi["tgl_transaksi"]; ?>">

        
            <label for="id_user">Id User</label> 
            <input type="text" name="id_user" id="id_user" class="form-control" value="<?= $transaksi["id_user"]; ?>">
            
            <label for="role">role</label> 
            <select name="role" class="form-control" value="<?= $transaksi["role"]; ?>">
                <option value="Admin">Admin</option>
                <option value="Customer">Customer</option>
            </select>
            <button type="submit" name="submit">Edit</button>

        </form>
        </div>
    </div>