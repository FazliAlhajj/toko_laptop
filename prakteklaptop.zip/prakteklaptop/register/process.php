<?php 

require '../koneksi.php';
$username = htmlspecialchars($_POST["username"]);
$password = htmlspecialchars($_POST["password"]);
$role = htmlspecialchars($_POST["role"]);

$query = mysqli_query($conn,"INSERT INTO user VALUES(NULL,'$username','$password','$role')");
    
if($query){
    echo "
        <script type='text/javascript'>
            alert('Register berhasil, silahkan login');
            window.location = '../login/index.php';
        </script>
    ";
}else{
    echo "
    <script type='text/javascript'>
        alert('Register gagal, silahkan cek data kamu kembali!');
        window.location = 'index.php';
    </script>
";
}

?>